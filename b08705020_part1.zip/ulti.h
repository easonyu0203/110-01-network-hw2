#ifndef ULTI
#define ULTI

#include<iostream>
#include<string>
#include<vector>

void ExitProgram(std::string why);
std::vector<std::string> Split(std::string str, std::string delimiter);

#endif